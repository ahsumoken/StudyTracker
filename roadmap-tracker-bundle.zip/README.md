# Roadmap Tracker

## Bestanden
- roadmap-tracker.html — Zelfstandig bestand, direct openen in browser
- index.html + style.css + app.js — Losse bestanden (ook direct bruikbaar)

## Gebruik
Open roadmap-tracker.html in je browser. Geen installatie nodig.
Data wordt opgeslagen via localStorage.

## Features
- Dashboard met voortgang en statistieken
- Categorieën met drag & drop
- Items met status, prioriteit, tags, deadline, leeruren
- Inbox, Weekplanning, Maanddoelen
- Skills matrix
- Reflecties en Doelen
- Alerts voor deadlines
- Historie / change log
- Rapportage (kopieer, print, markdown export)
- Export/Import JSON
- Dark/light theme
- Compacte modus
- Responsief (mobiel)
