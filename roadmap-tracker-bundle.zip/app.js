// ==========================================
// ROADMAP TRACKER — APP.JS
// ==========================================

// ==========================================
// DATA LAYER
// ==========================================
const DB_KEY = 'roadmap_tracker_v1';

const defaultData = {
  categories: [],
  inbox: [],
  weeks: [],
  months: [],
  skills: [],
  reflections: [],
  goals: [],
  history: [],
  settings: { theme: 'dark', compact: false }
};

function loadData() {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (!raw) return JSON.parse(JSON.stringify(defaultData));
    const d = JSON.parse(raw);
    // ensure all keys exist
    return Object.assign({}, JSON.parse(JSON.stringify(defaultData)), d);
  } catch(e) {
    return JSON.parse(JSON.stringify(defaultData));
  }
}

function saveData() {
  localStorage.setItem(DB_KEY, JSON.stringify(state));
}

let state = loadData();

// ==========================================
// UTILITIES
// ==========================================
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function now() { return new Date().toISOString(); }

function fmtDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString('nl-NL', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function fmtDateTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleString('nl-NL', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function isOverdue(deadline) {
  if (!deadline) return false;
  return new Date(deadline) < new Date() && deadline;
}

function isWithin7Days(deadline) {
  if (!deadline) return false;
  const d = new Date(deadline);
  const n = new Date();
  return d >= n && (d - n) <= 7 * 86400000;
}

function esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function logHistory(action, desc) {
  state.history.unshift({ id: uid(), action, desc, ts: now() });
  if (state.history.length > 500) state.history = state.history.slice(0, 500);
}

// ==========================================
// MODAL SYSTEM
// ==========================================
let modalSaveCallback = null;

function openModal(title, bodyHTML, onSave) {
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').innerHTML = bodyHTML;
  document.getElementById('modalOverlay').style.display = 'flex';
  modalSaveCallback = onSave;
}

function closeModal() {
  document.getElementById('modalOverlay').style.display = 'none';
  modalSaveCallback = null;
}

document.getElementById('modalClose').addEventListener('click', closeModal);
document.getElementById('modalCancel').addEventListener('click', closeModal);
document.getElementById('modalSave').addEventListener('click', () => {
  if (modalSaveCallback) modalSaveCallback();
});
document.getElementById('modalOverlay').addEventListener('click', e => {
  if (e.target === document.getElementById('modalOverlay')) closeModal();
});

// ==========================================
// NAVIGATION
// ==========================================
let currentView = 'dashboard';

function showView(name) {
  currentView = name;
  document.querySelectorAll('.view').forEach(v => v.style.display = 'none');
  const el = document.getElementById('view-' + name);
  if (el) el.style.display = 'block';

  document.querySelectorAll('.nav-links a').forEach(a => {
    a.classList.toggle('active', a.dataset.view === name);
  });

  const titles = {
    dashboard: 'Dashboard', categories: 'Categorieën', inbox: 'Inbox',
    week: 'Weekplanning', month: 'Maanddoelen', skills: 'Skills',
    reflections: 'Reflecties', goals: 'Doelen', alerts: 'Alerts',
    history: 'Historie', report: 'Rapportage', export: 'Export / Import'
  };
  document.getElementById('viewTitle').textContent = titles[name] || name;

  renderView(name);
}

function renderView(name) {
  switch(name) {
    case 'dashboard': renderDashboard(); break;
    case 'categories': renderCategories(); break;
    case 'inbox': renderInbox(); break;
    case 'week': renderWeeks(); break;
    case 'month': renderMonths(); break;
    case 'skills': renderSkills(); break;
    case 'reflections': renderReflections(); break;
    case 'goals': renderGoals(); break;
    case 'alerts': renderAlerts(); break;
    case 'history': renderHistory(); break;
    case 'report': renderReport(); break;
    case 'export': break;
  }
  renderAlertsBanner();
}

document.querySelectorAll('.nav-links a').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    showView(a.dataset.view);
    if (window.innerWidth <= 768) {
      document.getElementById('sidebar').classList.remove('mobile-open');
    }
  });
});

// ==========================================
// SIDEBAR CONTROLS
// ==========================================
document.getElementById('sidebarToggle').addEventListener('click', () => {
  const sidebar = document.getElementById('sidebar');
  sidebar.classList.toggle('collapsed');
  document.body.classList.toggle('sidebar-collapsed');
});

document.getElementById('menuBtn').addEventListener('click', () => {
  document.getElementById('sidebar').classList.toggle('mobile-open');
});

document.getElementById('themeToggle').addEventListener('click', () => {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  state.settings.theme = isDark ? 'light' : 'dark';
  saveData();
});

document.getElementById('compactToggle').addEventListener('click', () => {
  document.body.classList.toggle('compact');
  state.settings.compact = document.body.classList.contains('compact');
  saveData();
});

// Apply saved settings
function applySavedSettings() {
  document.documentElement.setAttribute('data-theme', state.settings.theme || 'dark');
  if (state.settings.compact) document.body.classList.add('compact');
}

// ==========================================
// DASHBOARD
// ==========================================
function renderDashboard() {
  const allItems = state.categories.flatMap(c => c.items || []);
  const done = allItems.filter(i => i.status === 'done' || i.completed);
  const progress = allItems.length ? Math.round((done.length / allItems.length) * 100) : 0;
  const totalHours = allItems.reduce((s, i) => s + (parseFloat(i.hours) || 0), 0);

  document.getElementById('statProgress').textContent = progress + '%';
  document.getElementById('statItems').textContent = allItems.length;
  document.getElementById('statDone').textContent = done.length;
  document.getElementById('statHours').textContent = totalHours.toFixed(1);
  document.getElementById('statSkills').textContent = state.skills.length;
  document.getElementById('statGoals').textContent = state.goals.length;

  // last changed
  const allTimes = [
    ...allItems.map(i => i.updatedAt || i.createdAt),
    ...state.history.map(h => h.ts)
  ].filter(Boolean).sort().reverse();
  document.getElementById('statLastChanged').textContent = allTimes[0] ? fmtDateTime(allTimes[0]) : '—';

  // week focus
  const currWeek = state.weeks[0];
  document.getElementById('statWeekFocus').textContent = currWeek ? currWeek.title || '—' : '—';

  // month focus
  const inProgressMonths = state.months.filter(m => m.status === 'doing');
  document.getElementById('statMonthFocus').textContent = inProgressMonths.length
    ? inProgressMonths.map(m => m.title).join(', ')
    : (state.months[0] ? state.months[0].title : '—');

  // category summaries
  const grid = document.getElementById('categorySummaryGrid');
  if (!state.categories.length) {
    grid.innerHTML = '<div class="empty-state"><div class="empty-icon">⊞</div>Nog geen categorieën. Maak er een aan in de Categorieën sectie.</div>';
    return;
  }
  grid.innerHTML = state.categories.map(cat => {
    const items = cat.items || [];
    const t = items.filter(i => i.status === 'todo').length;
    const d = items.filter(i => i.status === 'doing').length;
    const dn = items.filter(i => i.status === 'done' || i.completed).length;
    const h = items.reduce((s, i) => s + (parseFloat(i.hours) || 0), 0);
    const pct = items.length ? Math.round((dn / items.length) * 100) : 0;
    return `<div class="cat-summary-card" onclick="showView('categories')">
      <div class="cat-summary-title">${esc(cat.title)}</div>
      <div class="cat-summary-meta">
        <span class="badge badge-todo">${t} todo</span>
        <span class="badge badge-doing">${d} bezig</span>
        <span class="badge badge-done">${dn} klaar</span>
        ${h > 0 ? `<span class="badge badge-hours">${h.toFixed(1)}u</span>` : ''}
      </div>
      <div class="cat-progress">
        <div class="progress-bar-wrap"><div class="progress-bar" style="width:${pct}%"></div></div>
      </div>
    </div>`;
  }).join('');
}

// ==========================================
// ALERTS BANNER
// ==========================================
function renderAlertsBanner() {
  const allItems = state.categories.flatMap(c => c.items || []);
  const overdue = allItems.filter(i => isOverdue(i.deadline) && i.status !== 'done' && !i.completed);
  const soon = allItems.filter(i => isWithin7Days(i.deadline) && i.status !== 'done' && !i.completed);
  const banner = document.getElementById('alertsBanner');
  if (overdue.length || soon.length) {
    banner.style.display = 'flex';
    banner.innerHTML = [
      overdue.length ? `⚠ ${overdue.length} achterstallige deadline${overdue.length > 1 ? 's' : ''}` : '',
      soon.length ? `◷ ${soon.length} deadline${soon.length > 1 ? 's' : ''} binnen 7 dagen` : ''
    ].filter(Boolean).map(s => `<span>${s}</span>`).join('');
  } else {
    banner.style.display = 'none';
  }
}

// ==========================================
// CATEGORIES
// ==========================================
let statusFilter = 'all';
let deadlineFilter = 'all';
let searchQuery = '';

function renderCategories() {
  updateCategoryJump();
  const list = document.getElementById('categoriesList');
  if (!state.categories.length) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">⊞</div>Nog geen categorieën.</div>';
    return;
  }
  list.innerHTML = state.categories.map((cat, ci) => renderCategoryCard(cat, ci)).join('');
  initCategoryDragDrop();
  initItemDragDrop();
}

function renderCategoryCard(cat, ci) {
  const items = (cat.items || []).filter(item => {
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      if (!( (item.text || '').toLowerCase().includes(q) ||
             (item.tags || []).some(t => t.toLowerCase().includes(q)) ||
             (item.note || '').toLowerCase().includes(q) )) return false;
    }
    if (statusFilter !== 'all' && item.status !== statusFilter) return false;
    if (deadlineFilter === 'overdue' && !isOverdue(item.deadline)) return false;
    if (deadlineFilter === 'week' && !isWithin7Days(item.deadline)) return false;
    if (deadlineFilter === 'none' && item.deadline) return false;
    return true;
  });

  const total = (cat.items || []).length;
  const done = (cat.items || []).filter(i => i.status === 'done' || i.completed).length;
  const pct = total ? Math.round((done / total) * 100) : 0;

  return `<div class="category-card" id="cat-${cat.id}" data-cat-id="${cat.id}" draggable="true">
    <div class="category-header">
      <span class="drag-handle" title="Slepen">⠿</span>
      <div class="cat-header-info">
        <div class="category-title">${esc(cat.title)}</div>
        ${cat.desc ? `<div class="category-desc">${esc(cat.desc)}</div>` : ''}
        <div class="cat-progress">
          <div class="progress-bar-wrap" style="width:100px"><div class="progress-bar" style="width:${pct}%"></div></div>
        </div>
      </div>
      <div class="category-actions">
        <button class="btn-icon" onclick="editCategory('${cat.id}')" title="Bewerken">✎</button>
        <button class="btn-icon" onclick="deleteCategory('${cat.id}')" title="Verwijderen" style="color:var(--red)">✕</button>
      </div>
    </div>
    <div class="category-items" id="items-${cat.id}" data-cat-id="${cat.id}">
      ${items.length === 0 && searchQuery ? '<div class="no-results">Geen items gevonden.</div>' : ''}
      ${items.map(item => renderItemCard(item, cat.id)).join('')}
      <button class="add-item-btn" onclick="addItem('${cat.id}')">+ Item toevoegen</button>
    </div>
  </div>`;
}

function renderItemCard(item, catId) {
  const overdue = isOverdue(item.deadline) && item.status !== 'done' && !item.completed;
  const soon = isWithin7Days(item.deadline) && item.status !== 'done' && !item.completed;
  const tags = (item.tags || []).map(t => `<span class="tag">${esc(t)}</span>`).join('');
  return `<div class="item-card" id="item-${item.id}" data-item-id="${item.id}" data-cat-id="${catId}" draggable="true">
    <div class="priority-dot priority-${item.priority || 'normal'}" title="Prioriteit: ${item.priority || 'normal'}"></div>
    <input type="checkbox" class="item-check" ${item.completed ? 'checked' : ''} onchange="toggleItemDone('${catId}','${item.id}', this.checked)" />
    <div class="item-main">
      <div class="item-text ${item.completed ? 'done' : ''}">${esc(item.text || '(geen tekst)')}</div>
      <div class="item-meta">
        <span class="status-badge status-${item.status || 'todo'}">${item.status || 'todo'}</span>
        ${tags}
        ${item.deadline ? `<span class="deadline-tag ${overdue ? 'overdue' : ''}">${overdue ? '⚠ ' : soon ? '◷ ' : ''}${fmtDate(item.deadline)}</span>` : ''}
        ${item.hours ? `<span class="hours-tag">⏱ ${item.hours}u</span>` : ''}
      </div>
    </div>
    <div class="item-actions">
      <button class="btn-icon" onclick="editItem('${catId}','${item.id}')" title="Bewerken">✎</button>
      <button class="btn-icon" onclick="deleteItem('${catId}','${item.id}')" title="Verwijderen" style="color:var(--red)">✕</button>
    </div>
  </div>`;
}

function updateCategoryJump() {
  const sel = document.getElementById('categoryJump');
  sel.innerHTML = '<option value="">— Ga naar —</option>' +
    state.categories.map(c => `<option value="cat-${c.id}">${esc(c.title)}</option>`).join('');
  sel.onchange = () => {
    const el = document.getElementById(sel.value);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    sel.value = '';
  };
}

// Add Category
document.getElementById('addCategoryBtn').addEventListener('click', () => {
  openModal('Nieuwe categorie', categoryFormHTML(), () => {
    const title = document.getElementById('f-cat-title').value.trim();
    if (!title) return alert('Titel is verplicht.');
    const cat = {
      id: uid(), title,
      desc: document.getElementById('f-cat-desc').value.trim(),
      items: [], createdAt: now()
    };
    state.categories.push(cat);
    logHistory('AANGEMAAKT', `Categorie: ${title}`);
    saveData(); closeModal(); renderCategories();
  });
});

function categoryFormHTML(cat = {}) {
  return `<div class="form-group"><label>Titel</label><input type="text" id="f-cat-title" value="${esc(cat.title || '')}" /></div>
  <div class="form-group"><label>Omschrijving</label><textarea id="f-cat-desc">${esc(cat.desc || '')}</textarea></div>`;
}

function editCategory(id) {
  const cat = state.categories.find(c => c.id === id);
  if (!cat) return;
  openModal('Categorie bewerken', categoryFormHTML(cat), () => {
    const title = document.getElementById('f-cat-title').value.trim();
    if (!title) return alert('Titel is verplicht.');
    cat.title = title;
    cat.desc = document.getElementById('f-cat-desc').value.trim();
    logHistory('BEWERKT', `Categorie: ${title}`);
    saveData(); closeModal(); renderCategories();
  });
}

function deleteCategory(id) {
  const cat = state.categories.find(c => c.id === id);
  if (!cat) return;
  if (!confirm(`Categorie "${cat.title}" en alle items verwijderen?`)) return;
  state.categories = state.categories.filter(c => c.id !== id);
  logHistory('VERWIJDERD', `Categorie: ${cat.title}`);
  saveData(); renderCategories();
}

// Add Item
function addItem(catId) {
  openModal('Nieuw item', itemFormHTML(), () => saveItem(catId, null));
}

function editItem(catId, itemId) {
  const cat = state.categories.find(c => c.id === catId);
  const item = (cat?.items || []).find(i => i.id === itemId);
  if (!item) return;
  openModal('Item bewerken', itemFormHTML(item), () => saveItem(catId, itemId));
}

function itemFormHTML(item = {}) {
  return `
  <div class="form-group"><label>Tekst</label><input type="text" id="f-item-text" value="${esc(item.text || '')}" /></div>
  <div class="form-row">
    <div class="form-group"><label>Status</label>
      <select id="f-item-status">
        <option value="todo" ${item.status === 'todo' || !item.status ? 'selected' : ''}>Todo</option>
        <option value="doing" ${item.status === 'doing' ? 'selected' : ''}>Bezig</option>
        <option value="done" ${item.status === 'done' ? 'selected' : ''}>Klaar</option>
      </select>
    </div>
    <div class="form-group"><label>Prioriteit</label>
      <select id="f-item-priority">
        <option value="low" ${item.priority === 'low' ? 'selected' : ''}>Laag</option>
        <option value="normal" ${item.priority === 'normal' || !item.priority ? 'selected' : ''}>Normaal</option>
        <option value="high" ${item.priority === 'high' ? 'selected' : ''}>Hoog</option>
      </select>
    </div>
  </div>
  <div class="form-row">
    <div class="form-group"><label>Deadline</label><input type="date" id="f-item-deadline" value="${item.deadline ? item.deadline.slice(0,10) : ''}" /></div>
    <div class="form-group"><label>Leeruren</label><input type="number" id="f-item-hours" value="${item.hours || ''}" min="0" step="0.5" /></div>
  </div>
  <div class="form-group"><label>Tags (kommagescheiden)</label><input type="text" id="f-item-tags" value="${esc((item.tags || []).join(', '))}" /></div>
  <div class="form-group"><label>Notitie</label><textarea id="f-item-note">${esc(item.note || '')}</textarea></div>
  <div class="form-group"><label>Reflectie</label><textarea id="f-item-reflection">${esc(item.reflection || '')}</textarea></div>
  <div class="form-group"><label>Sterkte</label><input type="text" id="f-item-strength" value="${esc(item.strength || '')}" /></div>
  <div class="form-group"><label>Leerpunt</label><input type="text" id="f-item-learning" value="${esc(item.learning || '')}" /></div>
  <div class="form-row">
    <div class="form-group"><label>Motivatie (1-5)</label><input type="number" id="f-item-motivation" value="${item.motivation || ''}" min="1" max="5" /></div>
    <div class="form-group"><label>Energie (1-5)</label><input type="number" id="f-item-energy" value="${item.energy || ''}" min="1" max="5" /></div>
  </div>
  <div class="form-group"><label>Begrip (1-5)</label><input type="number" id="f-item-understanding" value="${item.understanding || ''}" min="1" max="5" /></div>
  `;
}

function saveItem(catId, itemId) {
  const cat = state.categories.find(c => c.id === catId);
  if (!cat) return;
  const text = document.getElementById('f-item-text').value.trim();
  if (!text) return alert('Tekst is verplicht.');
  const status = document.getElementById('f-item-status').value;
  const tags = document.getElementById('f-item-tags').value.split(',').map(t => t.trim()).filter(Boolean);

  if (itemId) {
    const item = (cat.items || []).find(i => i.id === itemId);
    if (!item) return;
    const oldStatus = item.status;
    Object.assign(item, {
      text, status,
      priority: document.getElementById('f-item-priority').value,
      deadline: document.getElementById('f-item-deadline').value || null,
      hours: parseFloat(document.getElementById('f-item-hours').value) || null,
      tags,
      note: document.getElementById('f-item-note').value.trim(),
      reflection: document.getElementById('f-item-reflection').value.trim(),
      strength: document.getElementById('f-item-strength').value.trim(),
      learning: document.getElementById('f-item-learning').value.trim(),
      motivation: parseInt(document.getElementById('f-item-motivation').value) || null,
      energy: parseInt(document.getElementById('f-item-energy').value) || null,
      understanding: parseInt(document.getElementById('f-item-understanding').value) || null,
      updatedAt: now()
    });
    if (status === 'done' && !item.completed) { item.completed = true; item.completedAt = now(); }
    if (status !== 'done') { item.completed = false; item.completedAt = null; }
    if (oldStatus !== status) logHistory('STATUS', `${text}: ${oldStatus} → ${status}`);
    else logHistory('BEWERKT', `Item: ${text}`);
  } else {
    const item = {
      id: uid(), text, status,
      priority: document.getElementById('f-item-priority').value,
      deadline: document.getElementById('f-item-deadline').value || null,
      hours: parseFloat(document.getElementById('f-item-hours').value) || null,
      tags,
      note: document.getElementById('f-item-note').value.trim(),
      reflection: document.getElementById('f-item-reflection').value.trim(),
      strength: document.getElementById('f-item-strength').value.trim(),
      learning: document.getElementById('f-item-learning').value.trim(),
      motivation: parseInt(document.getElementById('f-item-motivation').value) || null,
      energy: parseInt(document.getElementById('f-item-energy').value) || null,
      understanding: parseInt(document.getElementById('f-item-understanding').value) || null,
      completed: status === 'done',
      completedAt: status === 'done' ? now() : null,
      createdAt: now(), updatedAt: now()
    };
    if (!cat.items) cat.items = [];
    cat.items.push(item);
    logHistory('AANGEMAAKT', `Item: ${text}`);
  }
  saveData(); closeModal(); renderCategories();
  if (currentView === 'dashboard') renderDashboard();
}

function deleteItem(catId, itemId) {
  const cat = state.categories.find(c => c.id === catId);
  if (!cat) return;
  const item = (cat.items || []).find(i => i.id === itemId);
  if (!item) return;
  if (!confirm(`Item "${item.text}" verwijderen?`)) return;
  logHistory('VERWIJDERD', `Item: ${item.text}`);
  cat.items = cat.items.filter(i => i.id !== itemId);
  saveData(); renderCategories();
}

function toggleItemDone(catId, itemId, checked) {
  const cat = state.categories.find(c => c.id === catId);
  const item = (cat?.items || []).find(i => i.id === itemId);
  if (!item) return;
  item.completed = checked;
  item.status = checked ? 'done' : 'todo';
  item.completedAt = checked ? now() : null;
  item.updatedAt = now();
  logHistory(checked ? 'VOLTOOID' : 'HEROPEND', `Item: ${item.text}`);
  saveData();
  renderCategories();
  if (currentView === 'dashboard') renderDashboard();
}

// Filters
document.getElementById('statusFilterChips').addEventListener('click', e => {
  const chip = e.target.closest('.chip');
  if (!chip) return;
  document.querySelectorAll('#statusFilterChips .chip').forEach(c => c.classList.remove('active'));
  chip.classList.add('active');
  statusFilter = chip.dataset.filter;
  renderCategories();
});

document.getElementById('deadlineFilter').addEventListener('change', e => {
  deadlineFilter = e.target.value;
  renderCategories();
});

document.getElementById('globalSearch').addEventListener('input', e => {
  searchQuery = e.target.value.trim();
  if (currentView === 'categories') renderCategories();
});

// ==========================================
// DRAG & DROP — CATEGORIES
// ==========================================
function initCategoryDragDrop() {
  const cards = document.querySelectorAll('.category-card');
  let dragSrc = null;

  cards.forEach(card => {
    card.addEventListener('dragstart', e => {
      dragSrc = card;
      card.style.opacity = '0.5';
      e.dataTransfer.effectAllowed = 'move';
    });
    card.addEventListener('dragend', () => { card.style.opacity = ''; });
    card.addEventListener('dragover', e => {
      e.preventDefault();
      cards.forEach(c => c.classList.remove('drag-over'));
      card.classList.add('drag-over');
    });
    card.addEventListener('dragleave', () => card.classList.remove('drag-over'));
    card.addEventListener('drop', e => {
      e.preventDefault();
      card.classList.remove('drag-over');
      if (!dragSrc || dragSrc === card) return;
      const srcId = dragSrc.dataset.catId;
      const tgtId = card.dataset.catId;
      const si = state.categories.findIndex(c => c.id === srcId);
      const ti = state.categories.findIndex(c => c.id === tgtId);
      if (si < 0 || ti < 0) return;
      const [item] = state.categories.splice(si, 1);
      state.categories.splice(ti, 0, item);
      saveData(); renderCategories();
    });
  });
}

// ==========================================
// DRAG & DROP — ITEMS
// ==========================================
function initItemDragDrop() {
  const itemEls = document.querySelectorAll('.item-card');
  let dragSrc = null;
  let dragSrcCat = null;

  itemEls.forEach(el => {
    el.addEventListener('dragstart', e => {
      dragSrc = el;
      dragSrcCat = el.dataset.catId;
      el.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
    });
    el.addEventListener('dragend', () => el.classList.remove('dragging'));
    el.addEventListener('dragover', e => {
      e.preventDefault();
      el.classList.add('drag-target');
    });
    el.addEventListener('dragleave', () => el.classList.remove('drag-target'));
    el.addEventListener('drop', e => {
      e.preventDefault();
      el.classList.remove('drag-target');
      if (!dragSrc || dragSrc === el) return;
      const srcItemId = dragSrc.dataset.itemId;
      const tgtItemId = el.dataset.itemId;
      const tgtCatId = el.dataset.catId;
      const srcCat = state.categories.find(c => c.id === dragSrcCat);
      const tgtCat = state.categories.find(c => c.id === tgtCatId);
      if (!srcCat || !tgtCat) return;
      const si = srcCat.items.findIndex(i => i.id === srcItemId);
      const ti = tgtCat.items.findIndex(i => i.id === tgtItemId);
      if (si < 0) return;
      const [item] = srcCat.items.splice(si, 1);
      tgtCat.items.splice(ti >= 0 ? ti : tgtCat.items.length, 0, item);
      saveData(); renderCategories();
    });
  });

  // Drop on container (empty area)
  document.querySelectorAll('.category-items').forEach(container => {
    container.addEventListener('dragover', e => e.preventDefault());
    container.addEventListener('drop', e => {
      e.preventDefault();
      if (!dragSrc) return;
      const tgtCatId = container.dataset.catId;
      const srcItemId = dragSrc.dataset.itemId;
      const srcCat = state.categories.find(c => c.id === dragSrcCat);
      const tgtCat = state.categories.find(c => c.id === tgtCatId);
      if (!srcCat || !tgtCat || srcCat === tgtCat) return;
      const si = srcCat.items.findIndex(i => i.id === srcItemId);
      if (si < 0) return;
      const [item] = srcCat.items.splice(si, 1);
      tgtCat.items.push(item);
      saveData(); renderCategories();
    });
  });
}

// ==========================================
// INBOX
// ==========================================
function renderInbox() {
  const list = document.getElementById('inboxList');
  if (!state.inbox.length) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">◻</div>Inbox is leeg.</div>';
    return;
  }
  list.innerHTML = state.inbox.map(n => `
    <div class="inbox-item">
      <input type="checkbox" ${n.completed ? 'checked' : ''} onchange="toggleInbox('${n.id}', this.checked)" />
      <span class="inbox-text ${n.completed ? 'done' : ''}">${esc(n.text)}</span>
      <button class="btn-icon" onclick="deleteInbox('${n.id}')" style="color:var(--red)">✕</button>
    </div>
  `).join('');
}

document.getElementById('addInboxBtn').addEventListener('click', () => {
  openModal('Nieuwe notitie', `<div class="form-group"><label>Notitie</label><textarea id="f-inbox-text" rows="3" autofocus></textarea></div>`, () => {
    const text = document.getElementById('f-inbox-text').value.trim();
    if (!text) return;
    state.inbox.push({ id: uid(), text, completed: false, createdAt: now() });
    saveData(); closeModal(); renderInbox();
  });
});

function toggleInbox(id, checked) {
  const n = state.inbox.find(i => i.id === id);
  if (n) { n.completed = checked; saveData(); renderInbox(); }
}

function deleteInbox(id) {
  state.inbox = state.inbox.filter(i => i.id !== id);
  saveData(); renderInbox();
}

// ==========================================
// WEEKS
// ==========================================
function renderWeeks() {
  const list = document.getElementById('weekList');
  if (!state.weeks.length) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">◫</div>Nog geen weekkaarten.</div>';
    return;
  }
  list.innerHTML = state.weeks.map(w => `
    <div class="week-card">
      <div class="week-card-title">${esc(w.title)}</div>
      <div class="week-card-note">${esc(w.note || '')}</div>
      <div style="margin-top:10px;display:flex;gap:6px">
        <button class="btn-icon" onclick="editWeek('${w.id}')">✎</button>
        <button class="btn-icon" onclick="deleteWeek('${w.id}')" style="color:var(--red)">✕</button>
      </div>
    </div>
  `).join('');
}

document.getElementById('addWeekBtn').addEventListener('click', () => {
  openModal('Nieuw week', weekFormHTML(), () => {
    const title = document.getElementById('f-week-title').value.trim();
    if (!title) return alert('Titel verplicht.');
    state.weeks.unshift({ id: uid(), title, note: document.getElementById('f-week-note').value.trim(), createdAt: now() });
    saveData(); closeModal(); renderWeeks();
  });
});

function weekFormHTML(w = {}) {
  return `<div class="form-group"><label>Titel</label><input type="text" id="f-week-title" value="${esc(w.title || '')}" /></div>
  <div class="form-group"><label>Notitie</label><textarea id="f-week-note">${esc(w.note || '')}</textarea></div>`;
}

function editWeek(id) {
  const w = state.weeks.find(x => x.id === id);
  if (!w) return;
  openModal('Week bewerken', weekFormHTML(w), () => {
    w.title = document.getElementById('f-week-title').value.trim();
    w.note = document.getElementById('f-week-note').value.trim();
    saveData(); closeModal(); renderWeeks();
  });
}

function deleteWeek(id) {
  if (!confirm('Week verwijderen?')) return;
  state.weeks = state.weeks.filter(w => w.id !== id);
  saveData(); renderWeeks();
}

// ==========================================
// MONTHS
// ==========================================
function renderMonths() {
  const list = document.getElementById('monthList');
  if (!state.months.length) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">◪</div>Nog geen maanddoelen.</div>';
    return;
  }
  list.innerHTML = state.months.map(m => `
    <div class="month-card">
      <div class="month-card-title">${esc(m.title)}</div>
      <span class="status-badge status-${m.status || 'todo'}">${m.status || 'todo'}</span>
      <div class="month-card-note" style="margin-top:6px">${esc(m.note || '')}</div>
      <div style="margin-top:10px;display:flex;gap:6px">
        <button class="btn-icon" onclick="editMonth('${m.id}')">✎</button>
        <button class="btn-icon" onclick="deleteMonth('${m.id}')" style="color:var(--red)">✕</button>
      </div>
    </div>
  `).join('');
}

document.getElementById('addMonthBtn').addEventListener('click', () => {
  openModal('Nieuw maanddoel', monthFormHTML(), () => {
    const title = document.getElementById('f-month-title').value.trim();
    if (!title) return alert('Titel verplicht.');
    state.months.push({
      id: uid(), title,
      status: document.getElementById('f-month-status').value,
      note: document.getElementById('f-month-note').value.trim(),
      createdAt: now()
    });
    saveData(); closeModal(); renderMonths();
  });
});

function monthFormHTML(m = {}) {
  return `<div class="form-group"><label>Titel</label><input type="text" id="f-month-title" value="${esc(m.title || '')}" /></div>
  <div class="form-group"><label>Status</label>
    <select id="f-month-status">
      <option value="todo" ${(m.status||'todo')==='todo'?'selected':''}>Todo</option>
      <option value="doing" ${m.status==='doing'?'selected':''}>Bezig</option>
      <option value="done" ${m.status==='done'?'selected':''}>Klaar</option>
    </select>
  </div>
  <div class="form-group"><label>Notitie</label><textarea id="f-month-note">${esc(m.note || '')}</textarea></div>`;
}

function editMonth(id) {
  const m = state.months.find(x => x.id === id);
  if (!m) return;
  openModal('Maanddoel bewerken', monthFormHTML(m), () => {
    m.title = document.getElementById('f-month-title').value.trim();
    m.status = document.getElementById('f-month-status').value;
    m.note = document.getElementById('f-month-note').value.trim();
    saveData(); closeModal(); renderMonths();
  });
}

function deleteMonth(id) {
  if (!confirm('Maanddoel verwijderen?')) return;
  state.months = state.months.filter(m => m.id !== id);
  saveData(); renderMonths();
}

// ==========================================
// SKILLS
// ==========================================
function renderSkills() {
  const summary = document.getElementById('skillsSummary');
  const list = document.getElementById('skillsList');

  if (state.skills.length) {
    const avgCurrent = (state.skills.reduce((s, sk) => s + (sk.current || 0), 0) / state.skills.length).toFixed(1);
    const avgTarget = (state.skills.reduce((s, sk) => s + (sk.target || 0), 0) / state.skills.length).toFixed(1);
    const gaps = state.skills.map(sk => ({ name: sk.name, gap: (sk.target || 0) - (sk.current || 0) }));
    const maxGap = gaps.sort((a, b) => b.gap - a.gap)[0];
    summary.innerHTML = `
      <div class="skill-stat">Gem. huidig niveau: <span>${avgCurrent}</span></div>
      <div class="skill-stat">Gem. doelniveau: <span>${avgTarget}</span></div>
      <div class="skill-stat">Grootste groeikloof: <span>${maxGap ? maxGap.name + ' (+' + maxGap.gap + ')' : '—'}</span></div>
      <div class="skill-stat">Totaal skills: <span>${state.skills.length}</span></div>
    `;
  } else {
    summary.innerHTML = '<div class="empty-state" style="padding:10px">Nog geen skills.</div>';
  }

  if (!state.skills.length) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">◈</div>Nog geen skills.</div>';
    return;
  }

  list.innerHTML = state.skills.map(sk => {
    const currentPct = Math.round((sk.current || 0) / 10 * 100);
    const targetPct = Math.round((sk.target || 0) / 10 * 100);
    return `<div class="skill-card">
      <div class="skill-name">${esc(sk.name)}</div>
      <div class="skill-levels">
        <span style="font-size:11px;color:var(--text2);width:60px">Huidig</span>
        <div class="skill-level-bar"><div class="skill-level-fill" style="width:${currentPct}%"></div></div>
        <span style="font-size:12px;font-family:var(--font-mono);color:var(--accent)">${sk.current || 0}/10</span>
      </div>
      <div class="skill-levels">
        <span style="font-size:11px;color:var(--text2);width:60px">Doel</span>
        <div class="skill-level-bar"><div class="skill-level-fill target" style="width:${targetPct}%"></div></div>
        <span style="font-size:12px;font-family:var(--font-mono);color:var(--accent3)">${sk.target || 0}/10</span>
      </div>
      ${sk.evidence ? `<div class="skill-meta">Bewijs: ${esc(sk.evidence)}</div>` : ''}
      ${sk.nextStep ? `<div class="skill-meta">Volgende stap: ${esc(sk.nextStep)}</div>` : ''}
      ${sk.date ? `<div class="skill-meta">Datum: ${fmtDate(sk.date)}</div>` : ''}
      <div style="margin-top:10px;display:flex;gap:6px">
        <button class="btn-icon" onclick="editSkill('${sk.id}')">✎</button>
        <button class="btn-icon" onclick="deleteSkill('${sk.id}')" style="color:var(--red)">✕</button>
      </div>
    </div>`;
  }).join('');
}

document.getElementById('addSkillBtn').addEventListener('click', () => {
  openModal('Nieuwe skill', skillFormHTML(), () => {
    const name = document.getElementById('f-sk-name').value.trim();
    if (!name) return alert('Naam verplicht.');
    state.skills.push({
      id: uid(), name,
      current: parseInt(document.getElementById('f-sk-current').value) || 0,
      target: parseInt(document.getElementById('f-sk-target').value) || 0,
      evidence: document.getElementById('f-sk-evidence').value.trim(),
      nextStep: document.getElementById('f-sk-nextstep').value.trim(),
      date: document.getElementById('f-sk-date').value || null,
      createdAt: now()
    });
    logHistory('AANGEMAAKT', `Skill: ${name}`);
    saveData(); closeModal(); renderSkills();
  });
});

function skillFormHTML(sk = {}) {
  return `<div class="form-group"><label>Naam</label><input type="text" id="f-sk-name" value="${esc(sk.name || '')}" /></div>
  <div class="form-row">
    <div class="form-group"><label>Huidig niveau (0-10)</label><input type="number" id="f-sk-current" value="${sk.current || 0}" min="0" max="10" /></div>
    <div class="form-group"><label>Doelniveau (0-10)</label><input type="number" id="f-sk-target" value="${sk.target || 0}" min="0" max="10" /></div>
  </div>
  <div class="form-group"><label>Bewijs</label><input type="text" id="f-sk-evidence" value="${esc(sk.evidence || '')}" /></div>
  <div class="form-group"><label>Volgende stap</label><input type="text" id="f-sk-nextstep" value="${esc(sk.nextStep || '')}" /></div>
  <div class="form-group"><label>Datum</label><input type="date" id="f-sk-date" value="${sk.date ? sk.date.slice(0,10) : ''}" /></div>`;
}

function editSkill(id) {
  const sk = state.skills.find(s => s.id === id);
  if (!sk) return;
  openModal('Skill bewerken', skillFormHTML(sk), () => {
    sk.name = document.getElementById('f-sk-name').value.trim();
    sk.current = parseInt(document.getElementById('f-sk-current').value) || 0;
    sk.target = parseInt(document.getElementById('f-sk-target').value) || 0;
    sk.evidence = document.getElementById('f-sk-evidence').value.trim();
    sk.nextStep = document.getElementById('f-sk-nextstep').value.trim();
    sk.date = document.getElementById('f-sk-date').value || null;
    logHistory('BEWERKT', `Skill: ${sk.name}`);
    saveData(); closeModal(); renderSkills();
  });
}

function deleteSkill(id) {
  const sk = state.skills.find(s => s.id === id);
  if (!sk || !confirm(`Skill "${sk.name}" verwijderen?`)) return;
  logHistory('VERWIJDERD', `Skill: ${sk.name}`);
  state.skills = state.skills.filter(s => s.id !== id);
  saveData(); renderSkills();
}

// ==========================================
// REFLECTIONS
// ==========================================
function renderReflections() {
  const list = document.getElementById('reflectionsList');
  if (!state.reflections.length) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">◉</div>Nog geen reflecties.</div>';
    return;
  }
  list.innerHTML = state.reflections.map(r => `
    <div class="reflection-card">
      <div class="reflection-title">${esc(r.title)}</div>
      <span class="status-badge status-${r.status || 'todo'}">${r.status || 'todo'}</span>
      <div class="reflection-text" style="margin-top:8px">${esc(r.text || '')}</div>
      <div style="margin-top:10px;display:flex;gap:6px">
        <button class="btn-icon" onclick="editReflection('${r.id}')">✎</button>
        <button class="btn-icon" onclick="deleteReflection('${r.id}')" style="color:var(--red)">✕</button>
      </div>
    </div>
  `).join('');
}

document.getElementById('addReflectionBtn').addEventListener('click', () => {
  openModal('Nieuwe reflectie', reflectionFormHTML(), () => {
    const title = document.getElementById('f-ref-title').value.trim();
    if (!title) return alert('Titel verplicht.');
    state.reflections.push({
      id: uid(), title,
      status: document.getElementById('f-ref-status').value,
      text: document.getElementById('f-ref-text').value.trim(),
      createdAt: now()
    });
    saveData(); closeModal(); renderReflections();
  });
});

function reflectionFormHTML(r = {}) {
  return `<div class="form-group"><label>Titel</label><input type="text" id="f-ref-title" value="${esc(r.title || '')}" /></div>
  <div class="form-group"><label>Status</label>
    <select id="f-ref-status">
      <option value="todo" ${(r.status||'todo')==='todo'?'selected':''}>Todo</option>
      <option value="doing" ${r.status==='doing'?'selected':''}>Bezig</option>
      <option value="done" ${r.status==='done'?'selected':''}>Klaar</option>
    </select>
  </div>
  <div class="form-group"><label>Tekst</label><textarea id="f-ref-text" rows="5">${esc(r.text || '')}</textarea></div>`;
}

function editReflection(id) {
  const r = state.reflections.find(x => x.id === id);
  if (!r) return;
  openModal('Reflectie bewerken', reflectionFormHTML(r), () => {
    r.title = document.getElementById('f-ref-title').value.trim();
    r.status = document.getElementById('f-ref-status').value;
    r.text = document.getElementById('f-ref-text').value.trim();
    saveData(); closeModal(); renderReflections();
  });
}

function deleteReflection(id) {
  if (!confirm('Reflectie verwijderen?')) return;
  state.reflections = state.reflections.filter(r => r.id !== id);
  saveData(); renderReflections();
}

// ==========================================
// GOALS
// ==========================================
function renderGoals() {
  const list = document.getElementById('goalsList');
  if (!state.goals.length) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">◎</div>Nog geen doelen.</div>';
    return;
  }
  list.innerHTML = state.goals.map(g => `
    <div class="goal-card">
      <div class="goal-horizon">${g.horizon || 'kort'} termijn</div>
      <div class="goal-title">${esc(g.title)}</div>
      <span class="status-badge status-${g.status || 'todo'}">${g.status || 'todo'}</span>
      <div class="goal-note" style="margin-top:6px">${esc(g.note || '')}</div>
      <div style="margin-top:10px;display:flex;gap:6px">
        <button class="btn-icon" onclick="editGoal('${g.id}')">✎</button>
        <button class="btn-icon" onclick="deleteGoal('${g.id}')" style="color:var(--red)">✕</button>
      </div>
    </div>
  `).join('');
}

document.getElementById('addGoalBtn').addEventListener('click', () => {
  openModal('Nieuw doel', goalFormHTML(), () => {
    const title = document.getElementById('f-goal-title').value.trim();
    if (!title) return alert('Titel verplicht.');
    state.goals.push({
      id: uid(), title,
      horizon: document.getElementById('f-goal-horizon').value,
      status: document.getElementById('f-goal-status').value,
      note: document.getElementById('f-goal-note').value.trim(),
      createdAt: now()
    });
    logHistory('AANGEMAAKT', `Doel: ${title}`);
    saveData(); closeModal(); renderGoals();
  });
});

function goalFormHTML(g = {}) {
  return `<div class="form-group"><label>Titel</label><input type="text" id="f-goal-title" value="${esc(g.title || '')}" /></div>
  <div class="form-row">
    <div class="form-group"><label>Horizon</label>
      <select id="f-goal-horizon">
        <option value="kort" ${(g.horizon||'kort')==='kort'?'selected':''}>Kort</option>
        <option value="middel" ${g.horizon==='middel'?'selected':''}>Middel</option>
        <option value="lang" ${g.horizon==='lang'?'selected':''}>Lang</option>
      </select>
    </div>
    <div class="form-group"><label>Status</label>
      <select id="f-goal-status">
        <option value="todo" ${(g.status||'todo')==='todo'?'selected':''}>Todo</option>
        <option value="doing" ${g.status==='doing'?'selected':''}>Bezig</option>
        <option value="done" ${g.status==='done'?'selected':''}>Klaar</option>
      </select>
    </div>
  </div>
  <div class="form-group"><label>Notitie</label><textarea id="f-goal-note">${esc(g.note || '')}</textarea></div>`;
}

function editGoal(id) {
  const g = state.goals.find(x => x.id === id);
  if (!g) return;
  openModal('Doel bewerken', goalFormHTML(g), () => {
    g.title = document.getElementById('f-goal-title').value.trim();
    g.horizon = document.getElementById('f-goal-horizon').value;
    g.status = document.getElementById('f-goal-status').value;
    g.note = document.getElementById('f-goal-note').value.trim();
    saveData(); closeModal(); renderGoals();
  });
}

function deleteGoal(id) {
  const g = state.goals.find(x => x.id === id);
  if (!g || !confirm('Doel verwijderen?')) return;
  logHistory('VERWIJDERD', `Doel: ${g.title}`);
  state.goals = state.goals.filter(x => x.id !== id);
  saveData(); renderGoals();
}

// ==========================================
// ALERTS VIEW
// ==========================================
function renderAlerts() {
  const view = document.getElementById('alertsView');
  const allItems = state.categories.flatMap(cat =>
    (cat.items || []).map(item => ({ ...item, catTitle: cat.title }))
  );
  const overdue = allItems.filter(i => isOverdue(i.deadline) && i.status !== 'done' && !i.completed);
  const soon = allItems.filter(i => isWithin7Days(i.deadline) && i.status !== 'done' && !i.completed);

  if (!overdue.length && !soon.length) {
    view.innerHTML = '<div class="empty-state"><div class="empty-icon">◬</div>Geen openstaande alerts.</div>';
    return;
  }

  view.innerHTML = [
    overdue.length ? `<h2 class="section-title">Achterstallige deadlines (${overdue.length})</h2>` : '',
    ...overdue.map(i => `
      <div class="alert-item overdue">
        <span class="alert-icon">⚠</span>
        <div class="alert-text">
          <strong>${esc(i.text)}</strong>
          <div class="alert-meta">${esc(i.catTitle)} · Deadline: ${fmtDate(i.deadline)}</div>
        </div>
      </div>
    `),
    soon.length ? `<h2 class="section-title" style="margin-top:20px">Binnen 7 dagen (${soon.length})</h2>` : '',
    ...soon.map(i => `
      <div class="alert-item soon">
        <span class="alert-icon">◷</span>
        <div class="alert-text">
          <strong>${esc(i.text)}</strong>
          <div class="alert-meta">${esc(i.catTitle)} · Deadline: ${fmtDate(i.deadline)}</div>
        </div>
      </div>
    `)
  ].join('');
}

// ==========================================
// HISTORY
// ==========================================
function renderHistory(query = '') {
  const list = document.getElementById('historyList');
  let items = state.history;
  if (query) {
    const q = query.toLowerCase();
    items = items.filter(h => h.desc.toLowerCase().includes(q) || h.action.toLowerCase().includes(q));
  }
  if (!items.length) {
    list.innerHTML = '<div class="empty-state"><div class="empty-icon">◷</div>Geen historierecords.</div>';
    return;
  }
  list.innerHTML = items.slice(0, 200).map(h => `
    <div class="history-item">
      <span class="history-time">${fmtDateTime(h.ts)}</span>
      <span class="history-action">${esc(h.action)}</span>
      <span class="history-desc">${esc(h.desc)}</span>
    </div>
  `).join('');
}

document.getElementById('historySearch').addEventListener('input', e => {
  renderHistory(e.target.value.trim());
});

document.getElementById('clearHistoryBtn').addEventListener('click', () => {
  if (!confirm('Alle historierecords wissen?')) return;
  state.history = [];
  saveData(); renderHistory();
});

// ==========================================
// REPORT
// ==========================================
function generateReportText() {
  const allItems = state.categories.flatMap(c => c.items || []);
  const done = allItems.filter(i => i.status === 'done' || i.completed).length;
  const progress = allItems.length ? Math.round((done / allItems.length) * 100) : 0;
  const totalHours = allItems.reduce((s, i) => s + (parseFloat(i.hours) || 0), 0);
  const d = new Date();
  const dateStr = d.toLocaleDateString('nl-NL', { day: '2-digit', month: 'long', year: 'numeric' });

  let lines = [];
  lines.push(`# Roadmap Tracker — Rapport`);
  lines.push(`Gegenereerd op: ${dateStr}`);
  lines.push('');
  lines.push(`## Overzicht`);
  lines.push(`- Voortgang: ${progress}%`);
  lines.push(`- Totaal items: ${allItems.length}`);
  lines.push(`- Voltooid: ${done}`);
  lines.push(`- Leeruren: ${totalHours.toFixed(1)}`);
  lines.push(`- Skills: ${state.skills.length}`);
  lines.push(`- Doelen: ${state.goals.length}`);
  lines.push(`- Maanddoelen: ${state.months.length}`);
  lines.push('');

  lines.push(`## Categorieën`);
  state.categories.forEach(cat => {
    const items = cat.items || [];
    const dn = items.filter(i => i.status === 'done' || i.completed).length;
    const h = items.reduce((s, i) => s + (parseFloat(i.hours) || 0), 0);
    lines.push(`### ${cat.title}`);
    lines.push(`- Items: ${items.length} (${dn} voltooid, ${h.toFixed(1)} uren)`);
    if (cat.desc) lines.push(`- ${cat.desc}`);
    items.forEach(item => {
      lines.push(`  - [${item.status || 'todo'}] ${item.text}${item.deadline ? ` (deadline: ${fmtDate(item.deadline)})` : ''}`);
    });
    lines.push('');
  });

  lines.push(`## Skills`);
  state.skills.forEach(sk => {
    lines.push(`- ${sk.name}: ${sk.current || 0}/10 → ${sk.target || 0}/10`);
    if (sk.nextStep) lines.push(`  Volgende stap: ${sk.nextStep}`);
  });
  lines.push('');

  lines.push(`## Doelen`);
  state.goals.forEach(g => {
    lines.push(`- [${g.horizon || 'kort'}] [${g.status || 'todo'}] ${g.title}`);
  });
  lines.push('');

  lines.push(`## Maanddoelen`);
  state.months.forEach(m => {
    lines.push(`- [${m.status || 'todo'}] ${m.title}`);
  });
  lines.push('');

  lines.push(`## Laatste wijziging`);
  const allTimes = state.history.map(h => h.ts).filter(Boolean).sort().reverse();
  lines.push(allTimes[0] ? fmtDateTime(allTimes[0]) : '—');

  return lines.join('\n');
}

function renderReport() {
  document.getElementById('reportContent').textContent = generateReportText();
}

document.getElementById('copyReportBtn').addEventListener('click', () => {
  navigator.clipboard.writeText(generateReportText()).then(() => alert('Rapport gekopieerd!'));
});
document.getElementById('printReportBtn').addEventListener('click', () => window.print());
document.getElementById('exportMdBtn').addEventListener('click', () => downloadText(generateReportText(), 'roadmap-rapport.md', 'text/markdown'));

// ==========================================
// EXPORT / IMPORT
// ==========================================
function downloadText(content, filename, mime = 'text/plain') {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([content], { type: mime }));
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

document.getElementById('exportJsonBtn').addEventListener('click', () => {
  downloadText(JSON.stringify(state, null, 2), 'roadmap-export.json', 'application/json');
});

document.getElementById('exportTxtBtn').addEventListener('click', () => {
  downloadText(generateReportText(), 'roadmap-rapport.txt');
});

document.getElementById('exportMdBtn2').addEventListener('click', () => {
  downloadText(generateReportText(), 'roadmap-rapport.md', 'text/markdown');
});

document.getElementById('importBtn').addEventListener('click', () => {
  const file = document.getElementById('importFile').files[0];
  if (!file) return alert('Selecteer een JSON-bestand.');
  const mode = document.querySelector('input[name="importMode"]:checked').value;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const imported = JSON.parse(e.target.result);
      if (mode === 'overwrite') {
        Object.assign(state, imported);
      } else {
        // merge
        ['categories', 'inbox', 'weeks', 'months', 'skills', 'reflections', 'goals', 'history'].forEach(key => {
          if (Array.isArray(imported[key])) {
            const existing = new Set((state[key] || []).map(x => x.id));
            const newItems = imported[key].filter(x => !existing.has(x.id));
            state[key] = [...(state[key] || []), ...newItems];
          }
        });
      }
      saveData();
      alert(`Import geslaagd (${mode === 'overwrite' ? 'overschreven' : 'samengevoegd'}).`);
      renderView(currentView);
    } catch(err) {
      alert('Import mislukt: ongeldig JSON-bestand.');
    }
  };
  reader.readAsText(file);
});

// ==========================================
// DOWNLOAD BUNDLE (ZIP)
// ==========================================
async function downloadBundle() {
  // Build a self-contained single HTML file as fallback + zip if JSZip available
  // We'll create a proper zip using a minimal zip implementation
  const files = {
    'index.html': await fetch('index.html').then(r => r.text()).catch(() => document.documentElement.outerHTML),
    'style.css': await fetch('style.css').then(r => r.text()).catch(() => '/* zie index.html */'),
    'app.js': await fetch('app.js').then(r => r.text()).catch(() => '/* zie index.html */')
  };

  // Use JSZip via CDN — but since we're offline-friendly, use a minimal approach:
  // Create a data blob with all files concatenated as a readable archive
  // For true ZIP, we use the browser's built-in approach with a self-contained single file

  // Create a single self-contained HTML file
  const cssContent = files['style.css'];
  const jsContent = files['app.js'];
  const htmlContent = files['index.html']
    .replace('<link rel="stylesheet" href="style.css" />', `<style>\n${cssContent}\n</style>`)
    .replace('<script src="app.js"></script>', `<script>\n${jsContent}\n</script>`);

  downloadText(htmlContent, 'roadmap-tracker.html', 'text/html');
  alert('Download gestart: roadmap-tracker.html\n\nDit is een volledig zelfstandig bestand dat je direct in de browser kunt openen. Alle data blijft opgeslagen via localStorage.');
}

document.getElementById('downloadBundleBtn').addEventListener('click', downloadBundle);
document.getElementById('quickDownloadBtn').addEventListener('click', downloadBundle);

// ==========================================
// KEYBOARD SHORTCUTS
// ==========================================
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});

// ==========================================
// INIT
// ==========================================
applySavedSettings();
showView('dashboard');
